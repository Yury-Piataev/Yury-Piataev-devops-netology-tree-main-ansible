# Ansible Collection - new_namespace.new_collection

Documentation for the collection.



```
root@vir-PC:/home/vir/dz/ansible/8.4/new_namespace/new_collection# ansible-playbook -i inventory/prod.yml site.yml
[WARNING]: You are running the development version of Ansible. You should only run Ansible from "devel" if you are modifying
the Ansible engine, or trying out features under development. This is a rapidly changing source of code and can become unstable
at any point.

PLAY [all] *********************************************************************************************************************

TASK [Gathering Facts] *********************************************************************************************************
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
ok: [centos]
ok: [elastic1]
ok: [ubuntu]

TASK [role : module] ***********************************************************************************************************
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
[WARNING]: The "docker" connection plugin has an improperly configured remote target value, forcing "inventory_hostname"
templated value instead of the string
ok: [elastic1]
ok: [ubuntu]
ok: [centos]

PLAY RECAP *********************************************************************************************************************
centos                     : ok=2    changed=0    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   
elastic1                   : ok=2    changed=0    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   
ubuntu                     : ok=2    changed=0    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   
```